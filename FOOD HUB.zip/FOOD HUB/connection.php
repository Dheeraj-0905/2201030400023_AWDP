// Create connection
<?php
    // $conn = new mysqli('your_db_host', 'your_db_username', 'your_db_password', 'your_db_name');
  $servername = "localhost";
$username = "root";
$password = "";
$dbname = "foodhub";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

?>